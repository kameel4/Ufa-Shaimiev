import sys, random, os
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt


class Ui_DemoKEG3(object):
    def setupUi(self, DemoKEG3):
        DemoKEG3.setObjectName("DemoKEG3")
        DemoKEG3.resize(946, 738)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(DemoKEG3.sizePolicy().hasHeightForWidth())
        DemoKEG3.setSizePolicy(sizePolicy)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        DemoKEG3.setPalette(palette)
        self.label = QtWidgets.QLabel(DemoKEG3)
        self.label.setGeometry(QtCore.QRect(210, 80, 491, 41))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(DemoKEG3)
        self.label_2.setGeometry(QtCore.QRect(80, 120, 901, 41))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Bahnschrift")
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(DemoKEG3)
        self.label_3.setGeometry(QtCore.QRect(80, 180, 151, 21))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift")
        font.setPointSize(11)
        font.setBold(False)
        font.setWeight(50)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.line = QtWidgets.QLineEdit(DemoKEG3)
        self.line.setGeometry(QtCore.QRect(80, 210, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift")
        font.setPointSize(12)
        self.line.setFont(font)
        self.line.setObjectName("line")
        self.startbtn = QtWidgets.QPushButton(DemoKEG3)
        self.startbtn.setGeometry(QtCore.QRect(190, 210, 111, 31))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(0, 170, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 170, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 170, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        self.startbtn.setPalette(palette)
        font = QtGui.QFont()
        font.setFamily("Bahnschrift")
        font.setPointSize(10)
        self.startbtn.setFont(font)
        self.startbtn.setFlat(False)
        self.startbtn.setObjectName("startbtn")

        self.retranslateUi(DemoKEG3)
        QtCore.QMetaObject.connectSlotsByName(DemoKEG3)

    def retranslateUi(self, DemoKEG3):
        _translate = QtCore.QCoreApplication.translate
        DemoKEG3.setWindowTitle(_translate("DemoKEG3", "DemoKEG3"))
        self.label.setText(_translate("DemoKEG3", "Демонстрационная версия станции КЕГЭ"))
        self.label_2.setText(_translate("DemoKEG3", "Предлагаемая демонстрационная версия позволяет проводить тренировку экзамена по\n"
"Информатике и ИКТ в компьютерной форме (КЕГЭ)."))
        self.label_3.setText(_translate("DemoKEG3", "Введите № КИМ:"))
        self.startbtn.setText(_translate("DemoKEG3", "Начать экзамен"))


class TBaseWindow(QWidget, Ui_DemoKEG3):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.balls = 0
        self.answerscount = 0
        self.answers = ['', '', '', '', '', '']
        self.answerquestion = 0
        self.grade = QLabel(self)
        self.grade.hide()
        self.startbtn.clicked.connect(self.press)
        self.pixmap = QPixmap('bluehead.png')
        self.image = QLabel(self)
        self.image.move(0, 0)
        self.image.resize(10000, 60)
        self.image.setPixmap(self.pixmap)
        self.pixmap1 = QPixmap('lightside.png')
        self.image1 = QLabel(self)
        self.image1.move(0, 60)
        self.image1.resize(70, 6800)
        self.image1.setPixmap(self.pixmap1)
        self.btn1 = QPushButton(self)
        self.btn1.setText('1')
        self.btn1.setFont(QFont('Bahnschrift', 12))
        self.btn1.resize(50, 50)
        self.btn1.move(7, 120)
        self.btn1.setStyleSheet("background-color: lightblue;")
        self.btn1.clicked.connect(self.problem_1)
        self.btn1.hide()
        self.btn2 = QPushButton(self)
        self.btn2.setText('2')
        self.btn2.setFont(QFont('Bahnschrift', 12))
        self.btn2.resize(50, 50)
        self.btn2.move(7, 175)
        self.btn2.setStyleSheet("background-color: lightblue;")
        self.btn2.clicked.connect(self.problem_2)
        self.btn2.hide()
        self.btn3 = QPushButton(self)
        self.btn3.setText('3')
        self.btn3.setFont(QFont('Bahnschrift', 12))
        self.btn3.resize(50, 50)
        self.btn3.move(7, 230)
        self.btn3.setStyleSheet("background-color: lightblue;")
        self.btn3.clicked.connect(self.problem_3)
        self.btn3.hide()
        self.btn4 = QPushButton(self)
        self.btn4.setText('4')
        self.btn4.setFont(QFont('Bahnschrift', 12))
        self.btn4.resize(50, 50)
        self.btn4.move(7, 285)
        self.btn4.setStyleSheet("background-color: lightblue;")
        self.btn4.clicked.connect(self.problem_4)
        self.btn4.hide()
        self.btn5 = QPushButton(self)
        self.btn5.setText('5')
        self.btn5.setFont(QFont('Bahnschrift', 12))
        self.btn5.resize(50, 50)
        self.btn5.move(7, 340)
        self.btn5.setStyleSheet("background-color: lightblue;")
        self.btn5.clicked.connect(self.problem_5)
        self.btn5.hide()
        self.btn6 = QPushButton(self)
        self.btn6.setText('6')
        self.btn6.setFont(QFont('Bahnschrift', 12))
        self.btn6.resize(50, 50)
        self.btn6.move(7, 395)
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn6.clicked.connect(self.problem_6)
        self.btn6.hide()
        self.btn_info = QPushButton(self)
        self.btn_info.setText('i')
        self.btn_info.setFont(QFont('Times New Roman', 15))
        self.btn_info.resize(50, 50)
        self.btn_info.move(7, 450)
        self.btn_info.setStyleSheet("background-color: lightblue;")
        self.btn_info.clicked.connect(self.info)
        self.btn_info.hide()
        self.btn_text_file = QPushButton(self)
        self.btn_text_file.setText('Просмотреть содержимое\nтекстового файла')
        self.btn_text_file.setFont(QFont('Bahnschrift', 12))
        self.btn_text_file.resize(self.btn_text_file.sizeHint())
        self.btn_text_file.setStyleSheet("background-color: lightblue;")
        self.btn_text_file.clicked.connect(self.text_file_press)
        self.btn_text_file.mean = 'text'
        self.btn_text_file.hide()
        self.btn_text_result = QPushButton(self)
        self.btn_text_result.setText('Просмотреть результат\nпримерного файла')
        self.btn_text_result.setFont(QFont('Bahnschrift', 12))
        self.btn_text_result.resize(self.btn_text_file.sizeHint())
        self.btn_text_result.setStyleSheet("background-color: lightblue;")
        self.btn_text_result.clicked.connect(self.text_file_press)
        self.btn_text_result.mean = 'result'
        self.btn_text_result.hide()
        self.kim = QLabel(self)
        self.an_label = QLabel(self, alignment=Qt.AlignCenter)
        self.an_label.setText('<h1 style="color: rgb(60, 179, 113);\
            ">Ответов: {}/6'.format(self.answerscount))
        self.an_label.setFont(QFont("Bahnschrift", 8, QFont.Bold))
        self.an_label.resize(self.an_label.sizeHint())
        self.an_label.move(70, 25)
        self.an_label.hide()
        self.keys = [
            ['tabl_1.png', 'graf_1.png', 'text_1.png', 'text_2.png', '9'],
            ['tabl_2.png', 'graf_2.png', 'text_1.png', 'text_2_2.png', '9'],
            ['tabl_3.png', 'graf_3.png', 'text1_2.png', 'text_2_3.png', '26'],
            ['problem2_1.png', 'zyxw'],
            ['problem2_2.png', 'xwzy'],
            ['problem2_3.png', 'zyxw'],
            ['[1; 1000]', '164'],
            ['[1024; 2048]', '244'],
            ['[2020; 3030]', '248'],
            ['prblm4_tabl.png', 'я четнаяа я четнаяя нечетная!'],
            ['вот это да, я даже картинки не использовал, балдежно', '1568'],
            ['ItsOkBro']
        ]
        self.n = random.randint(0, 2)
        self.n1 = random.randint(3, 5)
        self.n2 = random.randint(6, 8)
        self.n3 = -3
        self.n4 = -2
        self.n5 = -1
        self.pixmap3 = QPixmap(self.keys[self.n][0])
        self.image3 = QLabel(self)
        self.pixmap4 = QPixmap(self.keys[self.n][1])
        self.image4 = QLabel(self)
        self.pixmap5 = QPixmap(self.keys[self.n][2])
        self.image5 = QLabel(self)
        self.pixmap6 = QPixmap(self.keys[self.n][3])
        self.image6 = QLabel(self)
        self.pixmap7 = QPixmap(self.keys[self.n1][0])
        self.image7 = QLabel(self)
        self.pixmap8 = QPixmap(self.keys[self.n2][0])
        self.image8 = QLabel(self)
        self.new_label9 = QLabel(self)
        self.pixmap10 = QPixmap(self.keys[9][0])
        self.image10 = QLabel(self)
        self.pixmap11 = QPixmap('info.png')
        self.image11 = QLabel(self)
        self.new_label2 = QLabel(self)
        self.textedit1 = QTextEdit(self)
        self.textedit1.hide()
        self.textedit2 = QTextEdit(self)
        self.textedit2.hide()
        self.textedit3 = QTextEdit(self)
        self.textedit3.hide()
        self.prblm4text = QLabel(self)
        self.prblm4text.hide()
        self.prblm4text_1 = QLabel(self)
        self.prblm4text_1.hide()
        self.prblm5text = QLabel(self)
        self.prblm5text.hide()
        self.end_btn = QPushButton(self)
        self.end_btn.clicked.connect(self.pressEnd)
        self.end_btn.hide()
        self.answertext = QLabel(self)
        self.answerline = QLineEdit(self)
        self.answerline.setStyleSheet('Background-color: lavender;')
        self.answerbtn = QPushButton(self)
        self.answerbtn.clicked.connect(self.answerpress)
        self.answertext.hide()
        self.answerline.hide()
        self.answerbtn.hide()
        self.problem_1_list = [
            self.image3,
            self.image4,
            self.image5,
            self.image6,
        ]
        self.problem_2_list = [
            self.image7
        ]
        self.problem_3_list = [
            self.image8,
            self.new_label9
        ]
        self.problem_4_list = [
            self.textedit1,
            self.prblm4text,
            self.prblm4text_1,
            self.image10
        ]
        self.problem_5_list = [
            self.prblm5text,
            self.textedit2
        ]
        self.problem_6_list = [
            self.new_label2,
            self.btn_text_file,
            self.btn_text_result,
            self.textedit3
        ]
        self.info_list = [
            self.image11
        ]
        self.lists = [
            self.problem_1_list,
            self.problem_2_list,
            self.problem_3_list,
            self.problem_4_list,
            self.problem_5_list,
            self.problem_6_list,
            self.info_list
        ]

    def press(self):
        self.label.hide()
        self.label_2.hide()
        self.label_3.hide()
        self.line.hide()
        self.startbtn.hide()
        self.btn1.show()
        self.btn2.show()
        self.btn3.show()
        self.btn4.show()
        self.btn5.show()
        self.btn6.show()
        self.btn_info.show()
        self.an_label.show()
        self.problem_1()
        self.end_btn.setText('Завершить экзамен')
        self.end_btn.setFont(QFont('Bahnschrift', 10))
        self.end_btn.resize(self.end_btn.sizeHint())
        self.end_btn.setStyleSheet('Background-color: lightblue;')
        self.end_btn.move(815, 20)
        self.end_btn.show()
        if len(self.line.text()) == 0:
            r = random.sample(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], 9)
            self.kim.setText('<h1 style="color: rgb(250, 250, 250);">\
                КИМ №' + ''.join(r))
        else:
            self.kim.setText('<h1 style="color: rgb(250, 250, 250);">\
                КИМ №' + self.line.text())
        self.kim.setFont(QFont('Bahnschrift', 9))
        self.kim.resize(self.kim.sizeHint())
        self.kim.move(300, 22)

    def problem_1(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_1_list:
                    j.hide()
        self.answerquestion = 0
        self.answerline.setText(self.answers[self.answerquestion])
        self.image3.move(100, 200)
        self.image3.resize(230, 168)
        self.image3.setPixmap(self.pixmap3)
        self.image3.show()
        self.image4.move(350, 200)
        self.image4.resize(300, 182)
        self.image4.setPixmap(self.pixmap4)
        self.image4.show()
        self.image5.move(100, 100)
        self.image5.resize(700, 75)
        self.image5.setPixmap(self.pixmap5)
        self.image5.show()
        self.image6.move(100, 400)
        self.image6.resize(700, 120)
        self.image6.setPixmap(self.pixmap6)
        self.image6.show()
        self.answertext.show()
        self.answerline.show()
        self.answerbtn.show()
        self.answertext.setText('Ответ:')
        self.answertext.setFont(QFont('TimesNewRoman', 12))
        self.answertext.resize(self.answertext.sizeHint())
        self.answertext.move(100, 550)
        self.answerline.setFont(QFont('Bahnschrift', 12))
        self.answerline.resize(100, 25)
        self.answerline.move(100, 570)
        self.answerbtn.setFont(QFont('Bahnschrift', 12))
        self.answerbtn.setText('Вписать ответ')
        self.answerbtn.resize(self.answerbtn.sizeHint())
        self.answerbtn.move(210, 570)
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn1.setStyleSheet("background-color: royalblue;")
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn5.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def problem_2(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_2_list:
                    j.hide()
        self.answerquestion = 1
        self.answerline.setText(self.answers[self.answerquestion])
        self.image7.move(100, 30)
        self.image7.resize(900, 700)
        self.image7.setPixmap(self.pixmap7)
        self.image7.show()
        self.answertext.move(100, 670)
        self.answerline.move(100, 690)
        self.answerbtn.move(210, 690)
        self.answertext.show()
        self.answerline.show()
        self.answerbtn.show()
        self.answerbtn.setText('Вписать ответ')
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn2.setStyleSheet("background-color: royalblue;")
        self.btn1.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn5.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def problem_3(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_3_list:
                    j.hide()
        self.answerquestion = 2
        self.answerline.setText(self.answers[self.answerquestion])
        self.new_label9.setText(' Алгоритм вычисления значения функции F(n), где n –'
                                'натуральное число,\n задан следующими соотношениями:\n\n'
                                ' F(n) = n + 15, при n ≤ 5\n'
                                ' F(n) = F(n // 2) + n * n * n - 1, при чётных n > 5\n'
                                ' F(n) = F(n - 1) + 2 * n * n + 1, при нечётных n > 5\n\n'
                                'Здесь // обозначает деление нацело. Определите количество натуральных\n'
                                'значений n из отрезка {}, для которых значение F(n) содержит не\n'
                                'менее двух цифр 8'.format(self.keys[self.n2][0]))
        self.new_label9.setFont(QFont('Times New Roman', 17))
        self.new_label9.resize(self.new_label9.sizeHint())
        self.new_label9.move(110, 110)
        self.new_label9.show()
        self.answertext.move(115, 420)
        self.answerline.move(115, 440)
        self.answerbtn.move(220, 435)
        self.answertext.show()
        self.answerline.show()
        self.answerbtn.show()
        self.answerbtn.setText('Вписать ответ')
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn3.setStyleSheet("background-color: royalblue;")
        self.btn1.setStyleSheet('Background-color: lightblue;')
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn5.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def problem_4(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_4_list:
                    j.hide()
        self.answerline.setText(self.answers[self.answerquestion])
        self.answerquestion = 3
        self.answerline.hide()
        self.answertext.hide()
        self.answerbtn.move(100, 580)
        self.textedit1.move(100, 240)
        self.textedit1.resize(500, 300)
        self.textedit1.setStyleSheet('Background-color: lavender;')
        self.textedit1.setFont(QFont('Bahnschrift', 10))
        self.textedit1.show()
        self.prblm4text_1.setText('        Напишите функцию Fun(n) по описанным выше требованиям.\n\
        Обратите внимание, отправить надо только код самой функции')
        self.prblm4text_1.setFont(QFont('Times New Roman', 16))
        self.prblm4text_1.move(60, 140)
        self.prblm4text_1.resize(720, 120)
        self.prblm4text_1.show()
        self.prblm4text.setText('Функция Fun(n) получает аргумент n, который является массивом, элементами в нем\n'
                                'являются строки различной длины. Функция должна возвращать список, элементами \n'
                                'в котором сначала все четные строки, а потом все нечетные.')
        self.prblm4text.setFont(QFont('Times New Roman', 16))
        self.prblm4text.move(100, 60)
        self.prblm4text.resize(755, 120)
        self.prblm4text.show()
        self.answerbtn.setText('Отправить код')
        self.answerbtn.show()
        self.btn4.setStyleSheet("background-color: royalblue;")
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn1.setStyleSheet('Background-color: lightblue;')
        self.btn5.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def problem_5(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_5_list:
                    j.hide()
        self.answerline.setText(self.answers[self.answerquestion])
        self.answerquestion = 4
        self.answerbtn.move(110, 510)
        self.answerbtn.setText('Отправить код')
        self.answerbtn.show()
        self.answerline.hide()
        self.answertext.hide()
        self.prblm5text.setText('Напишите функцию F(mn, mx) в которой mn и mx - это два целых числа,\n'
                                'где первое меньше второго. Функция должна возвращать кол-во чисел,\n'
                                'которые делятся на 3 и не делятся на 7, 17, 19, 27 из диапозона [mn; mx]')
        self.prblm5text.setFont(QFont('Times New Roman', 16))
        self.prblm5text.move(110, 110)
        self.prblm5text.resize(720, 65)
        self.prblm5text.show()
        self.textedit2.move(110, 200)
        self.textedit2.resize(500, 300)
        self.textedit2.setStyleSheet('Background-color: lavender;')
        self.textedit2.setFont(QFont('Bahnschrift', 10))
        self.textedit2.show()
        self.btn5.setStyleSheet("background-color: royalblue;")
        self.btn6.setStyleSheet("background-color: lightblue;")
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn1.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def problem_6(self):
        for i in self.lists:
            for j in i:
                if i != self.problem_6_list:
                    j.hide()
        self.answerquestion = 5
        self.new_label2.setText('В файл arr.in.txt записан целочисленный массив из 30 элементов. Элементы массива\n'
                                'могут принимать натуральные значения от 1 до 10 000 включительно. Опишите\n'
                                'на языке программирования python 3.7 алгоритм, который находит\n'
                                'минимум среди элементов массива, не делящихся нацело на 6, а затем\n'
                                'заменяет каждый элемент, не делящийся нацело на 6, на число, равное\n'
                                'найденному минимуму. Гарантируется, что хотя бы один такой элемент в\n'
                                'массиве есть. Результат необходимо записать в файл arr.out.txt,\n'
                                'каждое число следует записывать на новой строке. Не забудьте закрыть файлы.'
                                '\n\t\t\t\t\t\t\t\t       *Ниже представлен пример\n'
                                '\t\t\t\t\t\t\t\t         массива из 6 элементов')
        self.new_label2.setFont(QFont('Times New Roman', 14))
        self.new_label2.move(100, 85)
        self.new_label2.resize(self.new_label2.sizeHint())
        self.new_label2.show()
        self.btn_text_file.move(720, 310)
        self.btn_text_file.show()
        self.btn_text_result.move(720, 360)
        self.btn_text_result.show()
        self.textedit3.move(100, 270)
        self.textedit3.resize(500, 300)
        self.textedit3.setStyleSheet('Background-color: lavender;')
        self.textedit3.setFont(QFont('Bahnschrift', 10))
        self.textedit3.show()
        self.answerbtn.move(100, 590)
        self.answerbtn.setText('отправить код')
        self.answerline.hide()
        self.answertext.hide()
        self.btn6.setStyleSheet("background-color: royalblue;")
        self.btn5.setStyleSheet("background-color: lightblue;")
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn1.setStyleSheet('Background-color: lightblue;')
        self.btn_info.setStyleSheet("background-color: lightblue;")

    def info(self):
        for i in self.lists:
            for j in i:
                if i != self.info_list:
                    j.hide()
        self.answerline.hide()
        self.answertext.hide()
        self.answerbtn.hide()
        self.image11.move(100, 70)
        self.image11.resize(625, 670)
        self.image11.setPixmap(self.pixmap11)
        self.image11.show()
        self.btn_info.setStyleSheet("background-color: royalblue;")
        self.btn1.setStyleSheet("background-color: lightblue;")
        self.btn2.setStyleSheet('Background-color: lightblue;')
        self.btn3.setStyleSheet('Background-color: lightblue;')
        self.btn4.setStyleSheet('Background-color: lightblue;')
        self.btn5.setStyleSheet('Background-color: lightblue;')

    def text_file_press(self):
        sender = self.sender()
        if sender.mean == 'text':
            os.system('notepad arr.in.demo.txt')
        else:
            os.system('notepad arr.out.demo.txt')

    def answerpress(self):
        if self.answerquestion == 3:
            try:
                exec(self.textedit1.toPlainText(), globals())
                self.answerline.setText(''.join(Fun(['я четная', 'я нечетная!', 'а я четная'])))
                print(Fun(['я четная', 'я нечетная!', 'а я четная']))
            except Exception:
                self.answerline.setText('NotEmpty')
        elif self.answerquestion == 4:
            try:
                exec(self.textedit2.toPlainText(), globals())
                self.answerline.setText(str(F(1016, 7937)))
            except Exception:
                self.answerline.setText('NotEmpty')
        elif self.answerquestion == 5:
            try:
                exec(self.textedit3.toPlainText(), globals())
                f = open('arr.out.txt', 'r')
                f1 = open('test.txt', 'r')
                data, data1 = f.readlines(), f1.readlines()
                if data == data1:
                    self.answerline.setText('ItsOkBro')
                else:
                    self.answerline.setText('ItsNotOkBro')
            except Exception:
                self.answerline.setText('ItsNotOkBro')
        if self.answers[self.answerquestion] == '':
            self.answerscount += 1
            self.an_label.setText('<h1 style="color: rgb(60, 179, 113);\
            ">Ответов: {}/6'.format(self.answerscount))
        self.answers[self.answerquestion] = self.answerline.text()

    def pressEnd(self):
        for i in self.lists:
            for j in i:
                j.hide()
        self.answerbtn.hide()
        self.answertext.hide()
        self.answerline.hide()
        self.true_answers = [
            self.keys[self.n][-1],
            self.keys[self.n1][-1],
            self.keys[self.n2][-1],
            self.keys[self.n3][-1],
            self.keys[self.n4][-1],
            self.keys[self.n5][-1],
        ]
        for i in range(len(self.answers)):
            print(self.answers[i], self.true_answers[i])
            if self.answers[i] == self.true_answers[i]:
                if i == 0:
                    self.balls += 10
                elif i == 1 or i == 2:
                    self.balls += 15
                else:
                    self.balls += 20
        self.grade.setText('Набрано {} баллов из 100'.format(self.balls))
        self.grade.setFont(QFont('Bahnschrift', 10))
        if self.balls < 50:
            self.grade.setText('<h1 style="color: rgb(255, 228, 0);">\
                {}'.format(self.grade.text()))
        elif self.balls < 80:
            self.grade.setText('<h1 style="color: rgb(127, 205, 13);">\
                            {}'.format(self.grade.text()))
        else:
            self.grade.setText('<h1 style="color: rgb(0, 154, 34);">\
                            {}'.format(self.grade.text()))
        self.grade.resize(self.grade.sizeHint())
        self.grade.move(100, 120)
        self.grade.show()
        self.btn1.hide()
        self.btn2.hide()
        self.btn3.hide()
        self.btn4.hide()
        self.btn5.hide()
        self.btn6.hide()
        self.btn_info.hide()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win1 = TBaseWindow()
    win1.show()
    sys.exit(app.exec())
